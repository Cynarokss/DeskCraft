import os
import textwrap
print("¡Hola! Bienvenido a DeskCraft.")
print("Pulsa 1 para crer un nuevo .desktop.")
print("Presiona 2 para salir.")
opcion = input(str("->"))

if opcion == "2":
    exit()
if opcion == "1":
    print("Nota: Los .desktop creados se guardaran en ~/.local/share/applications/")
    nombre = str(input("Nombre de la aplicación:")).strip()
    execute = str(input("Ruta del ejecutable (NO pongas ~/ para home, ponlo de esta forma /home/tu_usuario):")).strip()
    icono = str(input("Ruta del icono (opcional, no pongas nada y pulsa enter para omitir, tampoco pongas ~):")).strip()
    categoria = str(input("Categoría (Las categorias disponibles son: AudioVideo, Development, Education, Game, Graphics, Networks, Office, Science, Settings, System, Utility):")).strip()
    comentario = str(input("Comentario (opcional):")).strip()
    terminal = str(input("¿Ejecutar aplicación en la terminal? true/false:")).strip().lower()
    tipo = str(input("Tipo de la aplicación (Disponibles: Application/Link/Directory):")).strip()

    contenido = textwrap.dedent(f"""\
    [Desktop Entry]
    Name={nombre}
    Exec={execute}
    Icon={icono}
    Comment={comentario}
    Categories={categoria}
    Terminal={terminal}
    Type={tipo}
    """)

    ruta_archivo = f"{nombre.lower().replace(' ', '_')}.desktop"
    destino = os.path.join(os.path.expanduser("~"), ".local", "share", "applications", ruta_archivo)

    try:
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w") as f:
            f.write(contenido)
        print(f"Archivo creado en: {destino}")
    except Exception as e:
        print(f"Error al crear el archivo: {e}")