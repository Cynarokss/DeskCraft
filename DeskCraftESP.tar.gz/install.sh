#!/bin/bash

echo "Instalando DeskCraft..."

DEST="$HOME/.local/bin"
SCRIPT_NAME="deskcraft"
SOURCE="deskcraft.py"

mkdir -p "$DEST"

cp "$SOURCE" "$DEST/${SCRIPT_NAME}.py"

echo "#!/bin/bash
python3 \"$DEST/${SCRIPT_NAME}.py\"" > "$DEST/$SCRIPT_NAME"

chmod +x "$DEST/$SCRIPT_NAME"

if [[ ":$PATH:" != *":$DEST:"* ]]; then
    echo "$DEST no está en tu PATH."
    echo "Agrega esta línea a tu .bashrc o .zshrc:"
    echo "export PATH=\"$DEST:\$PATH\""
fi

echo "Instalación completa. Usa el comando 'deskcraft' desde cualquier terminal."

