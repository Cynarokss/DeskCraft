#!/bin/bash

echo "Desinstalando DeskCraft..."

DEST="$HOME/.local/bin"
SCRIPT_NAME="deskcraft"

rm -f "$DEST/$SCRIPT_NAME"
rm -f "$DEST/${SCRIPT_NAME}.py"

echo "DeskCraft ha sido eliminado de $DEST."

