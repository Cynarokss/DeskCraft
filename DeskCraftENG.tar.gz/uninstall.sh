#!/bin/bash

echo "Uninstalling DeskCraft..."

DEST="$HOME/.local/bin"
SCRIPT_NAME="deskcraft"

# Remove launcher and Python script
rm -f "$DEST/$SCRIPT_NAME"
rm -f "$DEST/${SCRIPT_NAME}.py"

# Confirm removal
echo "DeskCraft has been removed from $DEST."

