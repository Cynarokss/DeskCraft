import os
import textwrap
print("Hello! Welcome to DeskCraft.")
print("Press 1 to create a new .desktop file.")
print("Press 2 to exit.")
option = input(str("->"))

if option == "2":
    exit()
if option == "1":
    print("Note: Created .desktop files will be saved in ~/.local/share/applications/")
    name = str(input("Application name:")).strip()
    execute = str(input("Executable path (DO NOT use ~/ for home, use full path like /home/your_user):")).strip()
    icon = str(input("Icon path (optional, press enter to skip, don't use ~):")).strip()
    category = str(input("Category (Available categories: AudioVideo, Development, Education, Game, Graphics, Networks, Office, Science, Settings, System, Utility):")).strip()
    comment = str(input("Comment (optional):")).strip()
    terminal = str(input("Run application in terminal? true/false:")).strip().lower()
    tipo = str(input("Application type (Available: Application/Link/Directory):")).strip()

    content = textwrap.dedent(f"""\
    [Desktop Entry]
    Name={name}
    Exec={execute}
    Icon={icon}
    Comment={comment}
    Categories={category}
    Terminal={terminal}
    Type={tipo}
    """)

    file_name = f"{name.lower().replace(' ', '_')}.desktop"
    destination = os.path.join(os.path.expanduser("~"), ".local", "share", "applications", file_name)

    try:
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        with open(destination, "w") as f:
            f.write(content)
        print(f"File created at: {destination}")
    except Exception as e:
        print(f"Error creating file: {e}")

