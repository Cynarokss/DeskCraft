#!/bin/bash

echo "Installing DeskCraft..."

DEST="$HOME/.local/bin"
SCRIPT_NAME="deskcraft"
SOURCE="deskcraft.py"

mkdir -p "$DEST"

cp "$SOURCE" "$DEST/${SCRIPT_NAME}.py"

echo "#!/bin/bash
python3 \"$DEST/${SCRIPT_NAME}.py\"" > "$DEST/$SCRIPT_NAME"

chmod +x "$DEST/$SCRIPT_NAME"

ls "$DEST/$SCRIPT_NAME"

if [[ ":$PATH:" != *":$DEST:"* ]]; then
    echo "$DEST is not in your PATH."
    echo "Add this line to your .bashrc or .zshrc:"
    echo "export PATH=\"$DEST:\$PATH\""
fi

echo "Installation complete. Use the 'deskcraft' command in your terminal to start using it."

